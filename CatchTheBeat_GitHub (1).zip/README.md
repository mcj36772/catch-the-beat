# 🎮 Catch the Beat!

A fun, kid-friendly, techno-themed browser game. Click the falling beats to score points!

## 🕹 Features
- Colorful animations
- Background music
- Offline support (PWA)
- Mobile-friendly

## 📱 Install as an App
Visit the game on your mobile browser and tap "Add to Home Screen" to install.

## 🚀 GitHub Pages
To host this game on GitHub Pages:
1. Push this folder to a GitHub repo.
2. Go to **Settings > Pages** and set the source to `main` branch and root (`/`).
3. Visit your live game at:
```
https://<your-username>.github.io/catch-the-beat/
```
